## Summary
Describe the change in 1-3 sentences.

## Why this matters
Explain the problem solved, benchmark improved, or risk reduced.

## Change type
- [ ] docs
- [ ] dataset
- [ ] benchmark
- [ ] runtime
- [ ] adapter
- [ ] training config
- [ ] release / packaging

## Validation
- [ ] `python3 scripts/validate_repo.py`
- [ ] `python3 -m pytest tests -q`
- [ ] relevant execution path tested
- [ ] no unintended file-format regressions

## Evidence
Paste benchmark deltas, screenshots, receipts, or report paths.

## Risk review
- [ ] touches promotion gates
- [ ] touches schemas
- [ ] touches scoring logic
- [ ] touches runtime/model adapters
- [ ] touches release artifacts

## Notes for reviewers
Anything unusual, deferred, or intentionally left out.
