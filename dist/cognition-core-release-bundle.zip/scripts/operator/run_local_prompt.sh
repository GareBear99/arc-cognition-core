#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

ADAPTER="${COGNITION_RUNTIME_ADAPTER:-command}"
MODEL_PATH="${COGNITION_MODEL_PATH:-}"
COMMAND_TEMPLATE="${COGNITION_COMMAND_TEMPLATE:-}"
ARTIFACT_PATH="${COGNITION_EXEMPLAR_ARTIFACT:-$ROOT/exports/candidates/darpa_functional/exemplar_train/artifact_manifest.json}"
SYSTEM_PROMPT="${COGNITION_SYSTEM_PROMPT:-Plan, critique, repair, calibrate. Be bounded and honest.}"
TIMEOUT_SECONDS="${COGNITION_TIMEOUT_SECONDS:-120}"
FIRST_OUTPUT_TIMEOUT_SECONDS="${COGNITION_FIRST_OUTPUT_TIMEOUT_SECONDS:-30}"
IDLE_TIMEOUT_SECONDS="${COGNITION_IDLE_TIMEOUT_SECONDS:-20}"
MAX_OUTPUT_BYTES="${COGNITION_MAX_OUTPUT_BYTES:-262144}"

if [[ $# -lt 1 ]]; then
  cat <<'MSG'
Usage:
  scripts/operator/run_local_prompt.sh "your prompt here"

Environment:
  COGNITION_RUNTIME_ADAPTER=exemplar|command
  COGNITION_EXEMPLAR_ARTIFACT=/abs/path/to/artifact_manifest.json
  COGNITION_MODEL_PATH=/abs/path/to/model.gguf
  COGNITION_COMMAND_TEMPLATE='/abs/path/to/llama-cli -m {model} -f {combined_prompt_file}'
  COGNITION_SYSTEM_PROMPT='optional system prompt'
MSG
  exit 2
fi

PROMPT="$1"
RECEIPT_DIR="$ROOT/reports/user_runs"
mkdir -p "$RECEIPT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
RECEIPT_PATH="$RECEIPT_DIR/runtime_receipt_${ADAPTER}_${STAMP}.json"

COMMON_ARGS=(
  --adapter "$ADAPTER"
  --prompt "$PROMPT"
  --system-prompt "$SYSTEM_PROMPT"
  --receipt-path "$RECEIPT_PATH"
  --timeout-seconds "$TIMEOUT_SECONDS"
  --first-output-timeout-seconds "$FIRST_OUTPUT_TIMEOUT_SECONDS"
  --idle-timeout-seconds "$IDLE_TIMEOUT_SECONDS"
  --max-output-bytes "$MAX_OUTPUT_BYTES"
)

if [[ "$ADAPTER" == "exemplar" ]]; then
  python3 scripts/execution/run_direct_candidate.py "${COMMON_ARGS[@]}" --artifact "$ARTIFACT_PATH"
else
  if [[ -z "$COMMAND_TEMPLATE" ]]; then
    echo "COGNITION_COMMAND_TEMPLATE is required when adapter=command" >&2
    exit 2
  fi
  MODEL_ARGS=()
  if [[ -n "$MODEL_PATH" ]]; then
    MODEL_ARGS+=(--model "$MODEL_PATH")
  fi
  python3 scripts/execution/run_direct_candidate.py "${COMMON_ARGS[@]}" --command-template "$COMMAND_TEMPLATE" "${MODEL_ARGS[@]}"
fi

echo "Receipt written to: $RECEIPT_PATH"
