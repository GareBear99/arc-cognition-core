#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

ADAPTER="${COGNITION_RUNTIME_ADAPTER:-command}"
MODEL_PATH="${COGNITION_MODEL_PATH:-}"
COMMAND_TEMPLATE="${COGNITION_COMMAND_TEMPLATE:-}"
ARTIFACT_PATH="${COGNITION_EXEMPLAR_ARTIFACT:-$ROOT/exports/candidates/darpa_functional/exemplar_train/artifact_manifest.json}"
TIMEOUT_SECONDS="${COGNITION_TIMEOUT_SECONDS:-120}"
FIRST_OUTPUT_TIMEOUT_SECONDS="${COGNITION_FIRST_OUTPUT_TIMEOUT_SECONDS:-30}"
IDLE_TIMEOUT_SECONDS="${COGNITION_IDLE_TIMEOUT_SECONDS:-20}"
MAX_OUTPUT_BYTES="${COGNITION_MAX_OUTPUT_BYTES:-262144}"
OUT_DIR="${COGNITION_BENCHMARK_OUTPUT_DIR:-$ROOT/results/benchmark_runs}"
mkdir -p "$OUT_DIR"
RUN_ID="${COGNITION_RUN_ID:-local_$(date -u +%Y%m%dT%H%M%SZ)}"

ARGS=(
  --adapter "$ADAPTER"
  --timeout-seconds "$TIMEOUT_SECONDS"
  --first-output-timeout-seconds "$FIRST_OUTPUT_TIMEOUT_SECONDS"
  --idle-timeout-seconds "$IDLE_TIMEOUT_SECONDS"
  --max-output-bytes "$MAX_OUTPUT_BYTES"
  --run-id "$RUN_ID"
  --output-dir "$OUT_DIR"
)

if [[ "$ADAPTER" == "exemplar" ]]; then
  ARGS+=(--artifact "$ARTIFACT_PATH")
else
  if [[ -z "$COMMAND_TEMPLATE" ]]; then
    echo "COGNITION_COMMAND_TEMPLATE is required when adapter=command" >&2
    exit 2
  fi
  ARGS+=(--command-template "$COMMAND_TEMPLATE")
  if [[ -n "$MODEL_PATH" ]]; then
    ARGS+=(--model "$MODEL_PATH")
  fi
fi

python3 scripts/execution/run_model_benchmarks.py "${ARGS[@]}"
python3 scripts/execution/score_benchmark_outputs.py --run-id "$RUN_ID" --output-dir "$OUT_DIR"

echo "Benchmark run complete. Run ID: $RUN_ID"
