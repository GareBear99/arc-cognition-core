#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cat <<'MSG'

Cognition Core local runtime setup complete.

Next steps:
1. Place your GGUF model somewhere local, for example models/your-model.gguf
2. Place your direct binary or final .llamafile locally.
3. Run a direct-runtime doctor check, for example:
   python3 scripts/runtime/doctor_direct_runtime.py \
     --adapter command \
     --model /absolute/path/to/model.gguf \
     --command-template '/absolute/path/to/llama-cli -m {model} -f {combined_prompt_file}'

Or with a final llamafile artifact:
   python3 scripts/runtime/doctor_direct_runtime.py \
     --adapter command \
     --command-template '/absolute/path/to/model.llamafile -f {combined_prompt_file}'
MSG
