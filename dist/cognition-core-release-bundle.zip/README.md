# Cognition Core

Cognition Core is a **local-first cognition lab and runtime control plane** for building, benchmarking, and promoting GGUF-oriented cognition candidates.

Its final runtime doctrine is:
- **no server required**
- **native local execution is authoritative**
- **browser UI is optional**
- **CPU-capable direct binary execution is the target path**
- **llamafile-style final artifacts are supported**

## What is complete in this repo
- A functioning in-process local baseline model (`exemplar`)
- A direct local command adapter for one-shot native execution (`command`)
- Benchmark, scoring, promotion, validation, receipts, and artifact manifests
- Timeout guards for overall runtime, no-generation / first-output timeout, and mid-generation idle timeout
- A binary + GGUF composition step for a llamafile-style final artifact

## What still depends on your chosen upstream model toolchain
- Real SFT / LoRA training against a selected base family
- Real merge implementation for that family
- Real GGUF export implementation for that family
- Running benchmark loops against the actually produced GGUF artifact

## Runtime truth
This project does **not** claim pure browser-native execution for arbitrary large models.
The honest user-facing shape is: browser UI optional, local native binary execution authoritative, no always-on daemon required.

## Quick start
### 1. Validate the repo
```bash
python3 scripts/validate_repo.py
python3 -m pytest tests -q
```

### 2. Build the native functioning baseline
```bash
python3 scripts/training/train_exemplar_candidate.py --candidate darpa_functional
```

### 3. Run the baseline directly
```bash
python3 scripts/execution/run_direct_candidate.py \
  --adapter exemplar \
  --artifact exports/candidates/darpa_functional/exemplar_train/artifact_manifest.json \
  --prompt 'Audit this repo and preserve constraints.'
```

### 4. Benchmark the baseline
```bash
python3 scripts/execution/run_model_benchmarks.py \
  --adapter exemplar \
  --artifact exports/candidates/darpa_functional/exemplar_train/artifact_manifest.json
python3 scripts/execution/score_benchmark_outputs.py
```


## User-end local runtime
### One-shot local prompt
```bash
scripts/operator/run_local_prompt.sh "Audit this repo and preserve constraints."
```

### One-shot local GGUF model
```bash
export COGNITION_RUNTIME_ADAPTER=command
export COGNITION_MODEL_PATH=/absolute/path/to/model.gguf
export COGNITION_COMMAND_TEMPLATE='/absolute/path/to/llama-cli -m {model} -f {combined_prompt_file}'
scripts/operator/run_local_prompt.sh "Summarize the system and next actions."
```

### Benchmark a local GGUF model
```bash
export COGNITION_RUNTIME_ADAPTER=command
export COGNITION_MODEL_PATH=/absolute/path/to/model.gguf
export COGNITION_COMMAND_TEMPLATE='/absolute/path/to/llama-cli -m {model} -f {combined_prompt_file}'
scripts/operator/benchmark_local_model.sh
```

See also:
- `docs/USER_END_RUNTIME_FLOW_2026-04-14.md`
- `docs/BROWSER_UI_BOUNDARY_2026-04-14.md`
- `.env.direct-runtime.example`

## Direct native runtime examples
### A. Direct `llama-cli` style binary
```bash
python3 scripts/runtime/doctor_direct_runtime.py \
  --adapter command \
  --model /absolute/path/to/model.gguf \
  --command-template '/absolute/path/to/llama-cli -m {model} -f {combined_prompt_file}'
```

### B. Final self-contained `.llamafile` artifact
```bash
python3 scripts/runtime/doctor_direct_runtime.py \
  --adapter command \
  --command-template '/absolute/path/to/model.llamafile -f {combined_prompt_file}'
```

### C. Run a real direct candidate request
```bash
python3 scripts/execution/run_direct_candidate.py \
  --adapter command \
  --model /absolute/path/to/model.gguf \
  --command-template '/absolute/path/to/llama-cli -m {model} -f {combined_prompt_file}' \
  --timeout-seconds 120 \
  --first-output-timeout-seconds 30 \
  --idle-timeout-seconds 20 \
  --prompt 'Produce a bounded repair plan with rollback notes.'
```

## Build a llamafile-style final artifact
```bash
python3 scripts/runtime/compile_llamafile_from_binary.py \
  --runtime-binary /absolute/path/to/llamafile_runtime_binary \
  --gguf /absolute/path/to/model.gguf \
  --output builds/model.llamafile
```

## One-command lab controls
```bash
python3 cognition_lab.py validate
python3 cognition_lab.py train-functioning-model
python3 cognition_lab.py run-functioning-model
python3 cognition_lab.py doctor-runtime
python3 cognition_lab.py candidate-gate
```

## How it works for the user
1. The user downloads the app or opens the browser UI shell.
2. The UI asks for a local model artifact or uses a bundled exemplar baseline.
3. If the user has a GGUF model, Cognition Core invokes a local native binary directly, such as a `llama-cli` path or final `.llamafile`.
4. Prompts are written to temporary prompt files to avoid shell quoting failures.
5. The runtime watches for model loading, tokenization, first real output, stalled generation, and completion or failure.
6. The run emits a receipt with timing, hashes, finish reason, and runtime metadata.
7. The UI displays the result, but the authoritative execution happened locally on the user's machine.

## Supporting ecosystem doctrine
- Cleanroom Runtime: mindshape and bounded execution style
- ARC-Core: proposal, evidence, and authority-gating structure
- Arc-RAR: receipt/archive discipline
- OmniBinary: execution-lane honesty and preflight reasoning
- ARC Language Module: domain-pack and language-boundary reasoning

## Status
This repository is now a **production-shaped local cognition lab/control plane**.
It is **not yet** a fully self-contained foundation-model training stack.
